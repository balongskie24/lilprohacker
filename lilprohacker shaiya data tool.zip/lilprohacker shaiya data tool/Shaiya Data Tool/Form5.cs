﻿using System.Windows.Forms;

namespace Shaiya_Data_file_Tool
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
    }
}
