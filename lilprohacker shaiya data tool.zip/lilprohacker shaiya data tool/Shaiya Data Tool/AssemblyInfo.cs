﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTrademark("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
[assembly: AssemblyTitle("Shaiya Data file Tool")]
[assembly: AssemblyFileVersion("1.0.15.0")]
[assembly: AssemblyCopyright("Copyright © lilprohacker  2010")]
[assembly: AssemblyProduct("Shaiya Data file Tool")]
[assembly: Guid("6d1e0763-67f3-42e7-9c91-4811af14e771")]
[assembly: AssemblyVersion("1.0.15.0")]
