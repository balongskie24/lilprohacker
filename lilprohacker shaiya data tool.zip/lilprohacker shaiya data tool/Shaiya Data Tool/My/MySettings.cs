﻿using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;

namespace Shaiya_Data_file_Tool.My
{
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "9.0.0.0")]
    [CompilerGenerated]
    internal sealed class MySettings : ApplicationSettingsBase
    {
        private static MySettings defaultInstance = (MySettings)Synchronized(new MySettings());
        private static object addedHandlerLockObject = RuntimeHelpers.GetObjectValue(new object());
        private static bool addedHandler;

        [DebuggerNonUserCode]
        public MySettings()
        {
        }

        [DebuggerNonUserCode]
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        private static void AutoSaveSettings(object sender, EventArgs e)
        {
            if (!MyProject.Application.SaveMySettingsOnExit)
                return;
            MySettingsProperty.Settings.Save();
        }

        public static MySettings Default
        {
            get
            {
                if (!MySettings.addedHandler)
                {
                    object handlerLockObject = MySettings.addedHandlerLockObject;
                    ObjectFlowControl.CheckForSyncLockOnValueType(handlerLockObject);
                    Monitor.Enter(handlerLockObject);
                    try
                    {
                        if (!MySettings.addedHandler)
                        {
                            MyProject.Application.Shutdown += (ShutdownEventHandler)((sender, e) =>
                           {
                               if (!MyProject.Application.SaveMySettingsOnExit)
                                   return;
                               MySettingsProperty.Settings.Save();
                           });
                            MySettings.addedHandler = true;
                        }
                    }
                    finally
                    {
                        Monitor.Exit(handlerLockObject);
                    }
                }
                return MySettings.defaultInstance;
            }
        }

        [DefaultSettingValue("")]
        [DebuggerNonUserCode]
        [UserScopedSetting]
        public string txtEditor
        {
            get
            {
                return Conversions.ToString(this[nameof(txtEditor)]);
            }
            set
            {
                this[nameof(txtEditor)] = (object)value;
            }
        }

        [DefaultSettingValue("")]
        [DebuggerNonUserCode]
        [UserScopedSetting]
        public string hexEditor
        {
            get
            {
                return Conversions.ToString(this[nameof(hexEditor)]);
            }
            set
            {
                this[nameof(hexEditor)] = (object)value;
            }
        }

        [DebuggerNonUserCode]
        [DefaultSettingValue("")]
        [UserScopedSetting]
        public string photoEditor
        {
            get
            {
                return Conversions.ToString(this[nameof(photoEditor)]);
            }
            set
            {
                this[nameof(photoEditor)] = (object)value;
            }
        }

        [UserScopedSetting]
        [DebuggerNonUserCode]
        public ArrayList importedFiles
        {
            get
            {
                return (ArrayList)this[nameof(importedFiles)];
            }
            set
            {
                this[nameof(importedFiles)] = (object)value;
            }
        }

        [DebuggerNonUserCode]
        [DefaultSettingValue("")]
        [UserScopedSetting]
        public string lastSahOpen
        {
            get
            {
                return Conversions.ToString(this[nameof(lastSahOpen)]);
            }
            set
            {
                this[nameof(lastSahOpen)] = (object)value;
            }
        }
    }
}
