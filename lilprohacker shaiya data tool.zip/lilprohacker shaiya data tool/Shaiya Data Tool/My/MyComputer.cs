﻿using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

namespace Shaiya_Data_file_Tool.My
{
    [GeneratedCode("MyTemplate", "8.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal class MyComputer : Computer
    {
        [DebuggerHidden]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public MyComputer()
        {
        }
    }
}
