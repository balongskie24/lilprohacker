﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;
using Shaiya_Data_file_Tool;
using Shaiya_Data_file_Tool.My;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

[GeneratedCode("MyTemplate", "8.0.0.0")]
[StandardModule]
[HideModuleName]
internal sealed class MyProject
{
    [MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal sealed class MyForms
    {
        public Form1 m_Form1;

        public Form2 m_Form2;

        public Form3 m_Form3;

        public Form4 m_Form4;

        public Form5 m_Form5;

        public Form6 m_Form6;

        public settingForm m_settingForm;

        [ThreadStatic]
        private static Hashtable m_FormBeingCreated;

        public Form1 Form1
        {
            [DebuggerNonUserCode]
            get
            {
                m_Form1 = Create__Instance__(m_Form1);
                return m_Form1;
            }
            [DebuggerNonUserCode]
            set
            {
                if (value != m_Form1)
                {
                    if (value != null)
                    {
                        throw new ArgumentException("Property can only be set to Nothing");
                    }
                    Dispose__Instance__(ref m_Form1);
                }
            }
        }

        public Form2 Form2
        {
            [DebuggerNonUserCode]
            get
            {
                m_Form2 = Create__Instance__(m_Form2);
                return m_Form2;
            }
            [DebuggerNonUserCode]
            set
            {
                if (value != m_Form2)
                {
                    if (value != null)
                    {
                        throw new ArgumentException("Property can only be set to Nothing");
                    }
                    Dispose__Instance__(ref m_Form2);
                }
            }
        }

        public Form3 Form3
        {
            [DebuggerNonUserCode]
            get
            {
                m_Form3 = Create__Instance__(m_Form3);
                return m_Form3;
            }
            [DebuggerNonUserCode]
            set
            {
                if (value != m_Form3)
                {
                    if (value != null)
                    {
                        throw new ArgumentException("Property can only be set to Nothing");
                    }
                    Dispose__Instance__(ref m_Form3);
                }
            }
        }

        public Form4 Form4
        {
            [DebuggerNonUserCode]
            get
            {
                m_Form4 = Create__Instance__(m_Form4);
                return m_Form4;
            }
            [DebuggerNonUserCode]
            set
            {
                if (value != m_Form4)
                {
                    if (value != null)
                    {
                        throw new ArgumentException("Property can only be set to Nothing");
                    }
                    Dispose__Instance__(ref m_Form4);
                }
            }
        }

        public Form5 Form5
        {
            [DebuggerNonUserCode]
            get
            {
                m_Form5 = Create__Instance__(m_Form5);
                return m_Form5;
            }
            [DebuggerNonUserCode]
            set
            {
                if (value != m_Form5)
                {
                    if (value != null)
                    {
                        throw new ArgumentException("Property can only be set to Nothing");
                    }
                    Dispose__Instance__(ref m_Form5);
                }
            }
        }

        public Form6 Form6
        {
            [DebuggerNonUserCode]
            get
            {
                m_Form6 = Create__Instance__(m_Form6);
                return m_Form6;
            }
            [DebuggerNonUserCode]
            set
            {
                if (value != m_Form6)
                {
                    if (value != null)
                    {
                        throw new ArgumentException("Property can only be set to Nothing");
                    }
                    Dispose__Instance__(ref m_Form6);
                }
            }
        }

        public settingForm settingForm
        {
            [DebuggerNonUserCode]
            get
            {
                m_settingForm = Create__Instance__(m_settingForm);
                return m_settingForm;
            }
            [DebuggerNonUserCode]
            set
            {
                if (value != m_settingForm)
                {
                    if (value != null)
                    {
                        throw new ArgumentException("Property can only be set to Nothing");
                    }
                    Dispose__Instance__(ref this.m_settingForm);
                }
            }
        }

        [DebuggerHidden]
        private static T Create__Instance__<T>(T Instance) where T : Form, new()
        {
            if (Instance != null && !Instance.IsDisposed)
            {
                return Instance;
            }
            if (m_FormBeingCreated != null)
            {
                if (m_FormBeingCreated.ContainsKey(typeof(T)))
                {
                    throw new InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate"));
                }
            }
            else
            {
                m_FormBeingCreated = new Hashtable();
            }
            m_FormBeingCreated.Add(typeof(T), null);
            try
            {
                return new T();
            }
            catch (TargetInvocationException ex)
            {
                throw new InvalidOperationException(Utils.GetResourceString("WinForms_SeeInnerException", ex.InnerException.Message), ex.InnerException);
            }
            finally
            {
                m_FormBeingCreated.Remove(typeof(T));
            }
        }

        [DebuggerHidden]
        private void Dispose__Instance__<T>(ref T instance) where T : Form
        {
            instance.Dispose();
            instance = null;
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        [DebuggerHidden]
        public MyForms()
        {
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override bool Equals(object o)
        {
            return base.Equals(RuntimeHelpers.GetObjectValue(o));
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        internal new Type GetType()
        {
            return typeof(MyForms);
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        public override string ToString()
        {
            return base.ToString();
        }
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    [MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
    internal sealed class MyWebServices
    {
        [DebuggerHidden]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override bool Equals(object o)
        {
            return base.Equals(RuntimeHelpers.GetObjectValue(o));
        }

        [DebuggerHidden]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        [DebuggerHidden]
        [EditorBrowsable(EditorBrowsableState.Never)]
        internal new Type GetType()
        {
            return typeof(MyWebServices);
        }

        [DebuggerHidden]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override string ToString()
        {
            return base.ToString();
        }

        [DebuggerHidden]
        private static T Create__Instance__<T>(T instance) where T : new()
        {
            if (instance == null)
            {
                return new T();
            }
            return instance;
        }

        [DebuggerHidden]
        private void Dispose__Instance__<T>(ref T instance)
        {
            instance = default(T);
        }

        [DebuggerHidden]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public MyWebServices()
        {
        }
    }

    [ComVisible(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal sealed class ThreadSafeObjectProvider<T> where T : new()
    {
        [CompilerGenerated]
        [ThreadStatic]
        private static T m_ThreadStaticValue;

        internal T GetInstance
        {
            [DebuggerHidden]
            get
            {
                if (m_ThreadStaticValue == null)
                {
                    m_ThreadStaticValue = new T();
                }
                return ThreadSafeObjectProvider<T>.m_ThreadStaticValue;
            }
        }

        [EditorBrowsable(EditorBrowsableState.Never)]
        [DebuggerHidden]
        public ThreadSafeObjectProvider()
        {
        }
    }

    private static readonly ThreadSafeObjectProvider<MyComputer> m_ComputerObjectProvider = new ThreadSafeObjectProvider<MyComputer>();

    private static readonly ThreadSafeObjectProvider<MyApplication> m_AppObjectProvider = new ThreadSafeObjectProvider<MyApplication>();

    private static readonly ThreadSafeObjectProvider<User> m_UserObjectProvider = new ThreadSafeObjectProvider<User>();

    private static ThreadSafeObjectProvider<MyForms> m_MyFormsObjectProvider = new ThreadSafeObjectProvider<MyForms>();

    private static readonly ThreadSafeObjectProvider<MyWebServices> m_MyWebServicesObjectProvider = new ThreadSafeObjectProvider<MyWebServices>();

    [HelpKeyword("My.Computer")]
    internal static MyComputer Computer
    {
        [DebuggerHidden]
        get
        {
            return m_ComputerObjectProvider.GetInstance;
        }
    }

    [HelpKeyword("My.Application")]
    internal static MyApplication Application
    {
        [DebuggerHidden]
        get
        {
            return m_AppObjectProvider.GetInstance;
        }
    }

    [HelpKeyword("My.User")]
    internal static User User
    {
        [DebuggerHidden]
        get
        {
            return m_UserObjectProvider.GetInstance;
        }
    }

    [HelpKeyword("My.Forms")]
    internal static MyForms Forms
    {
        [DebuggerHidden]
        get
        {
            return m_MyFormsObjectProvider.GetInstance;
        }
    }

    [HelpKeyword("My.WebServices")]
    internal static MyWebServices WebServices
    {
        [DebuggerHidden]
        get
        {
            return m_MyWebServicesObjectProvider.GetInstance;
        }
    }
}
